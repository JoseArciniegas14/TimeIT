import { AlarmContainer } from ".";

export default {
  title: "Components/AlarmContainer",
  component: AlarmContainer,
};

export const Default = {
  args: {},
};
