/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const AlarmContainer = () => {
  return (
    <div className="ALARM-CONTAINER">
      <img className="line" alt="Line" src="https://c.animaapp.com/TL5YG686/img/line-1.svg" />
      <div className="alarm-name">Alarma</div>
      <div className="time">4:50 AM</div>
      <div className="overlap-group">
        <div className="swich" />
      </div>
    </div>
  );
};
