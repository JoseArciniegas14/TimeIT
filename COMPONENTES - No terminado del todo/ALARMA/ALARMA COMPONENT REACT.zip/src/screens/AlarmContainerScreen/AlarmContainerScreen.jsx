import React from "react";
import { AlarmContainer } from "../../components/AlarmContainer";

export const AlarmContainerScreen = () => {
  return <AlarmContainer />;
};
